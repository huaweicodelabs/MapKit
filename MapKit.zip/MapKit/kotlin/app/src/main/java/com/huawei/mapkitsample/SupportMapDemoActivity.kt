/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 *  2020.1.3-Changed modify the import classes type and add some SupportMapFragment demos.
 *                  Huawei Technologies Co., Ltd.
 *
 */

package com.huawei.mapkitsample

import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.huawei.hms.maps.CameraUpdateFactory
import com.huawei.hms.maps.HuaweiMap
import com.huawei.hms.maps.OnMapReadyCallback
import com.huawei.hms.maps.SupportMapFragment
import com.huawei.hms.maps.model.BitmapDescriptorFactory
import com.huawei.hms.maps.model.LatLng
import com.huawei.hms.maps.model.Marker
import com.huawei.hms.maps.model.MarkerOptions
import kotlinx.android.synthetic.main.activity_supportmapfragment_demo.*

/**
 * Create a simple activity with a map and a marker on the map.
 */
class SupportMapDemoActivity : AppCompatActivity(), OnMapReadyCallback {
    private var hMap: HuaweiMap? = null
    private lateinit var mSupportMapFragment: SupportMapFragment
    private var mBeijing: Marker? = null
    private var mShanghai: Marker? = null
    private var mNanjing: Marker? = null
    companion object {
        private const val TAG = "SupportMapDemoActivity"
        private val Beijing = LatLng(48.893478, 2.334595)
        private val Shanghai = LatLng(48.7, 2.12)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d(TAG, "onCreate: ")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_supportmapfragment_demo)
        mSupportMapFragment = supportFragmentManager.findFragmentById(R.id.supportMap) as SupportMapFragment
        mSupportMapFragment.getMapAsync(this)

        btnAddMarker.setOnClickListener {
            addMarker()
        }
        btnSetVisiable.setOnClickListener {
            setVisible()
        }
        btnSetFlat.setOnClickListener {
            setFlat()
        }
        btnSetAlpha.setOnClickListener {
            setAlpha()
        }
        btnSetAnchor.setOnClickListener {
            setAnchor()
        }
        btnSetZIndex.setOnClickListener {
            setZIndex()
        }
        btnSetRotation.setOnClickListener {
            setRotation()
        }
        btnRemoveMarker.setOnClickListener {
            setRotation()
        }
        btnShowInfoWindow.setOnClickListener {
            showInfoWindow()
        }
        btnSetIcon.setOnClickListener {
            setIcon()
        }
    }

    override fun onMapReady(map: HuaweiMap) {
        Log.d(TAG, "onMapReady: ")
        hMap = map

        hMap?.apply {
            uiSettings?.isCompassEnabled = true
            moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(48.893478, 2.334595), 14f))
            setOnMapLongClickListener {
                Log.d(
                    TAG,
                    "onMapLongClick: latLng " + " please input latLng"
                )
            }
        }
    }
   private fun addMarker() {
        if (mBeijing == null && mShanghai == null && mNanjing == null) { // Uses a colored icon.
            mBeijing = hMap?.addMarker(
                MarkerOptions().position(Beijing).title("Beijing").clusterable(
                    true
                )
            )
            mShanghai = hMap?.addMarker(
                MarkerOptions().position(Shanghai)
                    .alpha(0.8f)
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.badge_ph))
            )
        }
            mBeijing?.let {
                mBeijing?.apply {
                    title = "hello"
                    snippet = "world"
                    tag = "huaweimap"
                    title = "Hello"
                }

        }
       mBeijing?.apply {
           isDraggable = true
           isDraggable = true
       }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mSupportMapFragment.onSaveInstanceState(outState)
    }

    private var visiable = true
   private fun setVisible() {
        if (visiable) {
            mBeijing?.isVisible = true
            visiable = false
        } else {
            mBeijing?.isVisible = false
            visiable = true
        }
    }

    private fun setAlpha() {
        if (visiable) {
            mBeijing?.alpha = 0.5f
            visiable = false
        } else {
            mBeijing?.alpha = 1.0f
            visiable = true
        }
    }

    private fun setFlat() {
        if (visiable) {
            mBeijing?.isFlat = true
            visiable = false
        } else {
            mBeijing?.isFlat = false
            visiable = true
        }
    }

    private fun setZIndex() {
        if (visiable) {
            mBeijing?.zIndex = 20f
            visiable = false
        } else {
            mBeijing?.zIndex = -20f
            visiable = true
        }
    }

    private fun setRotation() {
        if (visiable) {
            mBeijing?.rotation = 30.0f
            visiable = false
        } else {
            mBeijing?.rotation = 60.0f
            visiable = true
        }
    }

    private fun showInfoWindow() {
        visiable = if (visiable) {
            mBeijing?.showInfoWindow()
            false
        } else {
            mBeijing?.hideInfoWindow()
            true
        }
    }

    @Suppress("DEPRECATION")
    private fun setAnchor() {
        mBeijing?.let {
            mBeijing?.setAnchor(0.9f, 0.9f)
        }
    }

    private fun setIcon() {
            mBeijing?.let {
                val bitmap = BitmapFactory.decodeResource(resources, R.drawable.badge_tr)
                val bitmapDescriptor = BitmapDescriptorFactory.fromBitmap(bitmap)
                mBeijing?.setIcon(bitmapDescriptor)
            }
    }
}