/*
 * Copyright 2020. Huawei Technologies Co., Ltd. All rights reserved.

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
 */

package com.huawei.mapkitsample.utils

object CheckUtils {
    fun isNumber(value: String): Boolean {
        return isInteger(value) || isDouble(value)
    }

    /**
     * Check whether the character string is an integer.
     */
    fun isInteger(value: String): Boolean {
        return try {
            value.toInt()
            true
        } catch (e: NumberFormatException) {
            false
        }
    }

    /**
     * Check whether the character string is a floating point number.
     */
    fun isDouble(value: String): Boolean {
        return try {
            value.toDouble()
            if (value.contains(".")) {
                true
            } else false
        } catch (e: NumberFormatException) {
            false
        }
    }

    fun checkIsEdit(string: String?): Boolean {
        return string?.length == 0 || string?.isEmpty()!! || "" == string
    }

    fun checkIsRight(string: String): Boolean {
        return isNumber(string)
    }
}